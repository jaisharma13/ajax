<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>registration Page</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="js/jquery.dataTables.min.css">
    <link rel="stylesheet" href="js/jquery.js">

    <link rel="stylesheet" href="//cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="jquery-3.5.1.min.js"></script>

        
    <script>
        
    </script>

    
</head>



<style>
 
 h2 {
  text-align: center;
  color: white;
  font-size: 28px;

}

#submit:hover {
  background: #6f6c6c;
}
    table{
        border: 1px solid black;
        margin: 1px auto;
        padding: 8px 25px;
       background: #c5d1d5;
}
  tr{
      padding: 10px;
  }

  td{
      padding: 13px;
  }
body {
    background-image: url(abc.jpg);
}
  #course {
  width: 90px;
  height: 33px;
  background: white;
}
input#lastName,input#firstName ,#email,#mobile,#marks,#number,#mnumber  {
  width: 253px;
  height: 25px;
}
#comments {
  width: 250px;
      height: 52px;
}
#submit {
  width: 149px;
  height: 51px;
  border-radius: 9px;
  border: 1px;
}
#submit {
  width: 151px;
  height: 53px;
  border-radius: 9px;
  border: 1px;
  background: #77a9c6;
  color: white;
  font-size: 20px;
}
.error {
  color: red;
}
#user,#last,#error,#mobil,#gndr,#hob{
    color:red;

}

</style>


<body>
  <section class="bg-img">
    <h2>Student Registration</h2>
    <form  id="register" name="form" action="action.php" method="post" >
        <table>
            <tr>
                <td>
                    <label for="firstName">First Name</label>  </td>
                    <td>
                    <input type="text"  id="firstName"  name="firstName" maxlength="20" value="" placeholder="Please enter your name"  > <br> <span  id="user">*</span> <br> </td>
            </tr>
            <tr>
                    <td><label for="lastName">Last Name</label></td>
                    <td><input type="text" id="lastName"  name="lastName" placeholder="Please enter your last name" > <br> <span  id="last">*</span> </td>
                </tr>
                   <tr> 
                       <td><label for="email">Email</label></td>
                       <td><input type="text" id="email" value="" name="email" maxlength="20" placeholder="Enter your email" > <br><span  id="error"> *</td>
                </tr>
                <tr> 
                    <td><label for="mnumber">Mobile No.</td>
                    <td><input type="mnumber" id="mnumber"  name="mnumber" placeholder="Enter your 10 digit number" limit="10" > <br><span id="mobil"> *</span><br></td>
                 </tr>
                <tr>
                   <td> <label for="gender">Gender</label></td>
                   <td><label for="male">male</label>
                    <input type="radio" id="gender" name="gender" name="male" value="male">
                    <label for="female">female</label>
                    <input type="radio" id="gender" name="gender" name="female"  value="female">  <span  id="gndr">*</span><br></td> </td>
                </tr>
                <tr>
                    <td> <label for="hobbies">Hobbies</label></td>
    
                   <td>
                    <input type="checkbox" id="hobbies" name="hobbies" value="cricket">
                   <label for="cricket"> Cricket</label>
                   <input type="checkbox" id="hobbies" name="hobbies" value="traveling">
                   <label for="traveling"> Traveling</label>
                   <input type="checkbox" id="hobbies" name="hobbies" value="reading">
                   <label for="reading">Reading </label><br> <span  id="hob">* </td>
                </tr>
                <tr>
                    <td>  <label for="course">COURSE</label></td>
                    <td><select id="course" name="course">
                        <option value="course">MCA</option>
                        <option value="course">M.sc</option>
                        <option value="course">BCA</option>
                        <option value="course">B.sc</option> <br> <span  id="cr">* </td>
                      </select>
                    </td>
                </tr>
               
    
                <tr>
                    <td>  <label for="comments">Review</label></td>
                    <td>
                        <textarea name="comments" id="comments" placeholder="Please Give yours review here..." value="comments">
                         
                            </textarea>
                    </td>
                </tr>
                <tr>
                    
                </tr><td></td>
              
                <td><button type="submit" id="submit" name="forms" value="submit" >Submit</button>
             </td>
            </tr>
               
    
        </table>
 
  </form>




 </section>


 <script type="text/javascript">
 
 $(document).ready(function () {
 
 //Validate Username
 
 // $('#fnamee').show();
 
 $('#user').hide();
 
 $('#firstName').keyup(function () {
 
 validateUsername();
 
 });
 
 
 
 function validateUsername() {
 
 let usernameError;
 
 
 let rfname = /^[A-Za-z]+[a-zA-Z]+$/;
 
 let usernameValue = $('#firstName').val();
 
 if (usernameValue.length == "") {
 
 $('#user').show();
 $('#user').html("*enter your name here ");
 usernameError = false;
 
 return false;
 
 } else if ((usernameValue.length < 3) ||
 
 (usernameValue.length > 10)) {
 
 $('#user').show();
 
 $('#user').html("**length of username must be between 3 and 10");
 
 usernameError = false;
 
 return false;
 
 } else if (!rfname.test(usernameValue)) {
 
 $('#user').show();
 
 $('#user').html("** first name only contain charcter");
 
 usernameError = false;
 
 return false;
 
 
 } else {
 
 $('#user').hide();
 
 return true;
 
 

 
 }
 
 }
 
 // Validate last name
 
 
 
 //$('#lnamee').show();
 
 $('#last').hide();
 
 $('#lastName').keyup(function () {
 
 validatelatsname();
 
 });
 
 
 
 function validatelatsname() {
 
 let lastnameError;
 
 
 
 let rlname = /^[A-Za-z]+[a-zA-Z]+$/;
 
 let lastnameValue = $('#lastName').val();
 
 if (lastnameValue.length == "") {
 
 $('#last').show();
 $('#last').html("*enter last name here");
 
 lastnameError = false;
 
 return false;
 
 } else if ((lastnameValue.length < 3) ||
 
 (lastnameValue.length > 10)) {
 
 $('#last').show();
 
 $('#last').html("**length of last name must be between 3 and 10");
 
 lastnameError = false;
 
 return false;
 
 } else if (!rlname.test(lastnameValue)) {
 
 $('#last').show();
 
 $('#last').html("** last name only contain charcter");
 
 lastnameError = false;
 
 return false;
 
 
 
 } else {
 
 $('#last').hide();
 
 return true;
 
 
 
 }
 
 }
 
 
 
 // Validate Email
 
 
 
 $('#error').hide();
 
 $('#email').keyup(function () {
 validateeamil();
 
 });
 
 
 function validateeamil() {
 
 let emailError;
 
 let regex = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
 
 
 
 const email = $('#email').val();
 
 if (email.length == "") {
 
 $('#error').show();
 $('#error').html("*enter correct email address ");

 
 
 
 emailError = false;
 
 return false;
 
 } else if (!regex.test(email)) {
 
 $('#error').show();
 $('#error').html("*invalid email address ");
 
 emailError = false;
 
 return false;
 
 
 
 } else {
 
 $('#error').hide();
 
 return true;
 
 
 
 }
 
 
 
 }
 
 
 
 // vlaidate number
 
 $('#mobil').hide();
 
 $('#mnumber').keyup(function () {
 
 validatephone();
 
 });
 
 
 
 function validatephone() {
 
 let phoneError;
 
 
 
 const phone = $('#mnumber').val();
 
 let regex = /^(\+\d{1,3}[-]?)?\d{10}$/;
 
 if (phone.length == "") {
 
 $('#mobil').show();
 $('#mobil').html("*enter correct email number ");
 
 phoneError = false;
 
 return false;
 
 
 
 } else if (!regex.test(phone)) {
 
 $('#mobil').show();
 $('#mobil').html("*invalid number ");

 
 phoneError = false;
 
 return false;
 
 } else {
 
 $('#mobil').hide();
 
 return true;
 
 
 
 }
 
 }
 
 // VALIDATE GENDER
 
 $('#gndr').hide();
 
 $('#gender').change(function () {
 
 
 
 gendervalidate();
 
 });
 
 
 
 function gendervalidate() {
 
 let genderError;
 
 
 
 if ($('input[name="gender"]:checked').length == 0) {
 
 $('#gndr').show();
 $('#gndr').html("*select one element ");
 
 genderError = false;
 
 return false;
 
 } else {
 
 
 
 $('#gndr').hide();

 
 return true;
 
 
 
 }
 
 
 
 }
 
 
// validate hobby

$('#hob').hide();

$('#hobbies').change(function () {



hobbyvalidate();

});



function hobbyvalidate() {

let hobbyError;



if ($('input[type=checkbox]:checked').length == 0) {

$('#hob').show();
$('#hob').html("*select atleast one checkbox ");

hobbyError = false;

return false;



} else {

$('#hob').hide();

return true;


}



}




// validate course



$('#sub').hide();

$('#course').change(function () {

validatecourse();


});


function validatecourse() {

let courseerror;



var val = $('#course').val();

if (val == " course") {

$('#sub').show();
$('#sub').html("*select one ");

courseerror = false;

return false;

} else {

$('#sub').hide();

return true;

}

}



 
 // Submit button
 
 $('#register').submit(function (e) {
 
 e.preventDefault();
 
 
 
 let name = validateUsername();
 
 let lname = validatelatsname();
 
 let emailadd = validateeamil();
 
 let phoneno = validatephone();
 
 let gendersel = gendervalidate();

 let hobbysel = hobbyvalidate();

 let coursesel = validatecourse();
 
 
 
 
 if (name == true &&
 
 lname == true &&
 
 emailadd == true &&
 
 phoneno == true &&
 
 gendersel == true&&
 
 hobbysel == true&&

 coursesel == true){
 
 
 
 
 
 $.ajax({
 
 type: "POST",
 
 url: 'action.php',
 
 data: $(this).serialize(),
 
 success: function (dataresult) {
 
 $("#submit").html(dataresult);
 
 
 
 //window.location.href="show.php";
 
 // window.location.replace("https://www.tutorialrepublic.com/faq/how-to-redirect-to-another-web-page-using-jquery.php")
 
 // var jsonData = JSON.parse(response);
 
 // if (jsonData.success == "1") { 
 
 // // $("#basic-form")[0].reset();
 
 // window.location.replace( 'show.php');
 
 }
 
 
 
 
 
 });
 
 } else {
 
 alert("please enter all required fields");
 
 }
 
 
 
 
 
 });
 
 
 
 
 
 });
 
 
        
  </script>
 
 
 </script>
 
 
 
 </body>
 </html>



