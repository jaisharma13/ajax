<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table DATA</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="//cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
			  crossorigin="anonymous"></script>
</head>
<body>

<div class="table-responsive">
<form id="register">
                  <table class="table table-bordered" id="example">
						<thead>
							<tr>
								<th>ID</th>
								<th>firstName</th>
								<th>lastName</th>
								<th>email</th>
                                <th>mnumber</th>
                                <th>gender</th>
                                <th>hobbies</th>
                                <th>course</th>
                                <th>comments</th>
                                
							</tr>
						</thead>
					</table>
				</div>
			</div>
</form>


            <script src="https://code.jquery.com/jquery-3.6.0.js"
			integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
			crossorigin="anonymous"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
			<script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
			<script type="text/javascript">
            var dataTable;
				$(document).ready(function() {
					dataTable = $('#example').DataTable( {
						"ajax": {
							url: "index.php",
							type : "POST",
							data : {filter_data : function(){ return $('#register').serialize();}
						}
						},
						"columns" : [
						{ data : "ID"},
						{ data : "firstName"},
						{ data : "lastName"},
						{ data : "email"},
                        { data : "mnumber"},
                        { data : "gender"},
                        { data : "hobbies"},
                        { data : "course"},
                        { data : "comments"},
						]
					} );
				} );

				$('#register').submit(function(e){
					e.preventDefault();
					dataTable.ajax.reload();
				});
			</script>


    
</body>
</html>