<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update record</title>


    
</head>
<style>
 
 h2 {
  text-align: center;
  color: white;
  font-size: 28px;

}
    table{
        border: 1px solid black;
        margin: 1px auto;
        padding: 8px 25px;
       background: #c5d1d5;
}
  tr{
      padding: 10px;
  }

  td{
      padding: 13px;
  }
body {
    background-image: url(abc.jpg);
}
  #course {
  width: 90px;
  height: 33px;
  background: white;
}
input#lastName,input#firstName ,#email,#mobile,#marks,#number  {
  width: 253px;
  height: 25px;
}
#comments {
  width: 250px;
      height: 52px;
}
#btn {
  width: 149px;
  height: 51px;
  border-radius: 9px;
  border: 1px;
}
#btn {
  width: 151px;
  height: 53px;
  border-radius: 9px;
  border: 1px;
  background: #77a9c6;
  color: white;
  font-size: 20px;
}
.error {
  color: red;
}


#submit {
  width: 40%;
  height: 39px;
  background: #06062d;
  color: white;
}

</style>


<body>
  <section class="bg-img">
    <h2>update record</h2>


    <?php
        $conn = mysqli_connect("localhost","root","seasia@123","registrations") or die ("connection failed");
        $Id = $_GET['id'];
        $sql = "SELECT * FROM user WHERE Id = '$Id'";
        $result =mysqli_query($conn,$sql) or die ("Query uncessfull.");
        if (mysqli_num_rows($result) > 0)
        {
            while($row = mysqli_fetch_array($result)){
    ?>

<form  id="register" name="form" action="updateRecord.php" method="post" onsubmit=" validation()">

        <table>
            <tr>

            <td><input type="hidden" name="Id" value="<?php echo $row['Id']; ?>"/></td>
            </tr>
            <tr>
                <td>
                    <label for="firstName">First Name</label>  
                    <td>
                    <input type="text"  id="firstName"  name="firstName" value="<?php echo $row['firstName']; ?>" maxlength="20"  > <br> <span class="user"> </td>
            </tr>
            <tr>
                    <td><label for="lastName">Last Name</label></td>
                    <td><input type="text" id="lastName" name="lastName" value="<?php echo $row['lastName']; ?>" > <br> <span  id="last"></span> </td>
                </tr>
                   <tr> 
                       <td><label for="email">Email</label></td>
                       <td><input type="text" id="email"  name="email" maxlength="20" value="<?php echo $row['email']; ?>" > <span class="error"> </td>
                </tr>
                <tr> 
                    <td><label for="mnumber">Mobile No.</label></td>
                    <td><input type="mnumber" id="mnumber"  name="mnumber" maxlength="10" value="<?php echo $row['mnumber']; ?>" >  <br><span id="mobil"> </span><br></td>
                 </tr>
                <tr>
                   <td> <label for="gender">Gender</label></td>
                   <td><label for="fname">male</label>
                    <input type="radio" id="male" name="gender" value="male">
                    <label for="fname">female</label>
                    <input type="radio" id="female" name="gender" value="female"><br> <span  id="gndr"> </span><br></td> </td>
                </tr>
                <tr>
                    <td> <label for="hobbies">Hobbies</label></td>
    
                   <td>
                    <input type="checkbox" id="cricket" name="hobbies">
                   <label for="cricket"> Cricket</label>
                   <input type="checkbox" id="traveling" name="hobbies">
                   <label for="traveling"> Traveling</label>
                   <input type="checkbox" id="reading" name="hobbies">
                   <label for="reading">Reading </label> </td>
                </tr>
                <tr>
                    <td>  <label for="course">COURSE</label></td>
                    <td><select id="course" name="course">
                        <option value="MCA">MCA</option>
                        <option value="M.sc">M.sc</option>
                        <option value="BCA">BCA</option>
                        <option value="B.sc">B.sc</option>
                      </select>
                    </td>
                </tr>
               
    
                <tr>
                    <td>  <label for="comments">Review</label></td>
                    <td>
                        <textarea name="comments" id="comments" value="<?php echo $row['comments']; ?>">
                         
                            </textarea>
                    </td>
                </tr>
                <tr>
                    
                </tr><td></td>
              
                <td><button type="submit" id="submit" name="forms" value="submit" onsubmit=" validation()" >update</button>
             </td>
            </tr>
        
    
        </table>
 
  </form>

  <?php }
        }
    ?>


 </section>
    



<script>


function validation(){


  
    
  var Name = /^[A-Za-z]+$/;
var firstName=document.getElementById('firstName').value;


     if(firstName==""){
      document.getElementById('user').innerHTML="Please enter Firstname";
      
     }
      if(firstName.length<2){
          document.getElementById('user').innerHTML="atleast enter two character";
      }
      if(!isNaN(firstName)){
          document.getElementById('user').innerHTML="please enter alphabets";
          return false;
      }
      if(firstName.match(Name))
      true;

      else{
          document.getElementById('user').innerHTML = "only alphabets  allowed";
      return false;
    }


    var correct_match = /^[A-Za-z._]+$/;  
     var lastName=document.getElementById('lastName').value;

       if(lastName==""){
         document.getElementById('last').innerHTML="Please enter Firstname";
        
        }
      if(lastName.length<2){
          document.getElementById('last').innerHTML="atleast enter two character";
      }
      if(!isNaN(lastName)){
          document.getElementById('last').innerHTML="please enter alphabet";
          return false;
      }
      if(lastName.match(correct_match))
      true;

      else{
          document.getElementById('last').innerHTML = "only alphabets  allowed";
      return false;
    }

  
 
  
  

      
      var mnumber=document.getElementById('mnumber').value;
 if(mnumber==""){
      document.getElementById('mobil').innerHTML="Please enter mobile";
  }
  if(isNaN(mnumber)){
      document.getElementById('mobil').innerHTML="Please enter number";
      return false;
  }
  if(mnumber.length<10 || mnumber.length>10){
          document.getElementById('mobil').innerHTML="atleast enter ten number";
          return false;
      }
  else{
          document.getElementById('mobil').innerHTML="" ;
      }


      var gender = document.form.gender;
      for(i=0; i<gender.length; i++){
         if(gender[i].checked==true)
             return true;
      }
      document.getElementById('gndr').innerHTML = "please select gender"
      return false;
      
}
</script>
</body>
</html>