<?php
$Id = $_GET['id'];
$conn = mysqli_connect("localhost","root","seasia@123","registrations") or die ("connection failed");
$sql = "DELETE FROM user WHERE Id = {$Id}";
$result = mysqli_query($conn, $sql) or die ("query unsucessful");
if ($result==1) {
    echo"<script>alert('Your record has been delete Sucessfully');</script>";
} else {
    echo"<script>alert('Record Not Saved');</script>";
}
header("location: http://localhost/ajax/display.php");
mysqli_close($conn);
?>
